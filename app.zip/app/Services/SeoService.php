<?php

namespace App\Services;

use App\Models\Setting;

class SeoService
{
    /**
     * Get SEO data for a specific page.
     */
    public function getSeoData(string $page): array
    {
        $settings = app(SettingsService::class)->getAllSettings();
        
        $defaults = [
            'home' => [
                'title' => $settings['general']['site_name'] . ' - Ship Chandlery & Marine Services Since 2015',
                'description' => 'Professional ship chandlery and marine servicing company operating through a large network of reliable partners across Africa, Middle East, and Asia.',
                'keywords' => 'ship chandlery, marine services, bunker delivery, fresh water supply, lubricating oils, port services',
                'og_image' => null,
            ],
            'about-us' => [
                'title' => 'About Us - ' . $settings['general']['site_name'],
                'description' => 'Learn about ' . $settings['general']['site_name'] . ', our history, mission, and commitment to providing exceptional marine services since 2015.',
                'keywords' => 'about ' . $settings['general']['site_name'] . ', marine services company, ship chandlery Africa',
                'og_image' => null,
            ],
            'our-range' => [
                'title' => 'Our Services - ' . $settings['general']['site_name'],
                'description' => 'Discover our comprehensive range of marine services including fresh water supply, bunker delivery, provisions, lubricants, and waste management.',
                'keywords' => 'marine services, ship supplies, bunker delivery, fresh water, provisions',
                'og_image' => null,
            ],
            'our-customers' => [
                'title' => 'Our Customers - ' . $settings['general']['site_name'],
                'description' => 'See what our clients say about ' . $settings['general']['site_name'] . '. Trusted by ship owners, operators, and charterers worldwide.',
                'keywords' => 'marine services clients, shipping company testimonials',
                'og_image' => null,
            ],
            'contact' => [
                'title' => 'Contact Us - ' . $settings['general']['site_name'],
                'description' => 'Get in touch with ' . $settings['general']['site_name'] . ' for inquiries about our marine services, quotes, or partnership opportunities.',
                'keywords' => 'contact marine services, ship chandlery quote',
                'og_image' => null,
            ],
        ];

        // Check for custom SEO settings
        $seoKey = 'seo_' . str_replace('-', '_', $page) . '_title';
        $customTitle = $settings['seo'][$seoKey] ?? null;
        
        if ($customTitle) {
            return [
                'title' => $customTitle,
                'description' => $settings['seo']['seo_' . str_replace('-', '_', $page) . '_description'] ?? $defaults[$page]['description'],
                'keywords' => $defaults[$page]['keywords'],
                'og_image' => null,
            ];
        }

        return $defaults[$page] ?? $defaults['home'];
    }

    /**
     * Generate meta tags.
     */
    public function generateMetaTags(array $data): string
    {
        $html = '';
        
        if (!empty($data['title'])) {
            $html .= '<title>' . $data['title'] . '</title>' . "\n";
        }
        
        if (!empty($data['description'])) {
            $html .= '<meta name="description" content="' . e($data['description']) . '">' . "\n";
        }
        
        if (!empty($data['keywords'])) {
            $html .= '<meta name="keywords" content="' . e($data['keywords']) . '">' . "\n";
        }
        
        return $html;
    }
}
