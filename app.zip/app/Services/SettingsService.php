<?php

namespace App\Services;

use App\Models\Setting;

class SettingsService
{
    /**
     * Default settings.
     */
    protected array $defaults = [
        'general' => [
            'site_name' => 'WP Marine Limited',
            'site_tagline' => 'Ship Chandlery & Marine Services',
            'site_description' => 'Professional ship chandlery and marine servicing company',
            'site_logo' => null,
            'site_favicon' => null,
        ],
        'contact' => [
            'contact_email' => 'info@wpmarinelimited.com',
            'contact_phone' => '+233 262 772 397',
            'contact_address' => null,
        ],
        'email' => [
            'contact_email' => 'info@wpmarinelimited.com',
            'mail_mailer' => 'smtp',
            'mail_host' => 'smtp.mailtrap.io',
            'mail_port' => '2525',
            'mail_username' => null,
            'mail_password' => null,
            'mail_encryption' => null,
            'mail_from_address' => 'noreply@wpmarinelimited.com',
            'mail_from_name' => 'WP Marine Limited',
        ],
        'integrations' => [
            'google_analytics_id' => null,
            'google_tag_manager_id' => null,
            'analytics_enabled' => false,
            'recaptcha_site_key' => null,
            'recaptcha_secret_key' => null,
            'recaptcha_enabled' => false,
            'live_chat_enabled' => false,
            'live_chat_script' => null,
        ],
        'seo' => [
            'seo_home_title' => 'WP Marine Limited - Ship Chandlery & Marine Services',
            'seo_home_description' => 'Professional ship chandlery and marine servicing company',
            'seo_about_title' => 'About Us - WP Marine Limited',
            'seo_about_description' => 'Learn about WP Marine Limited',
        ],
        'social' => [
            'social_facebook' => null,
            'social_twitter' => null,
            'social_linkedin' => null,
            'social_instagram' => null,
        ],
        'gdpr' => [
            'gdpr_enabled' => true,
            'gdpr_cookie_banner' => true,
        ],
    ];

    /**
     * Get all settings.
     */
    public function getAllSettings(): array
    {
        $settings = Setting::getGroupedSettings();
        
        // Merge with defaults
        foreach ($this->defaults as $group => $defaults) {
            if (!isset($settings[$group])) {
                $settings[$group] = [];
            }
            
            foreach ($defaults as $key => $value) {
                if (!isset($settings[$group][$key])) {
                    $settings[$group][$key] = $value;
                }
            }
        }
        
        return $settings;
    }

    /**
     * Get setting value.
     */
    public function get(string $key, $default = null)
    {
        $setting = Setting::where('key', $key)->first();
        
        return $setting ? $setting->value : (
            isset($this->defaults[$key]) ? $this->defaults[$key] : $default
        );
    }

    /**
     * Set setting value.
     */
    public function set(string $key, $value): void
    {
        Setting::setValue($key, $value);
    }

    /**
     * Initialize default settings.
     */
    public function initDefaults(): void
    {
        foreach ($this->defaults as $group => $settings) {
            foreach ($settings as $key => $value) {
                if (!Setting::where('key', $key)->exists()) {
                    Setting::create([
                        'key' => $key,
                        'value' => $value,
                        'type' => 'text',
                        'group' => $group,
                    ]);
                }
            }
        }
    }
}
