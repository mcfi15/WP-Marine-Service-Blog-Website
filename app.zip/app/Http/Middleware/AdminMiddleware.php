<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('admin.login')->with('error', 'Please login to access the admin area.');
        }

        if (!auth()->user()->hasRole('admin')) {
            return redirect()->route('frontend.home')->with('error', 'You do not have permission to access the admin area.');
        }

        return $next($request);
    }
}
