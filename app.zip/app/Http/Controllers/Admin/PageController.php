<?php

namespace App\Http\Controllers\Admin;

use App\Models\Page;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class PageController extends AdminController
{
    /**
     * Display a listing of pages.
     */
    public function index(Request $request)
    {
        $query = Page::with(['creator', 'editor']);

        if ($request->has('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('slug', 'like', '%' . $request->search . '%');
            });
        }

        $pages = $query->orderBy('order')->paginate(15);

        return view('admin.pages.index', compact('pages'));
    }

    /**
     * Show the form for creating a new page.
     */
    public function create()
    {
        $parentPages = Page::where('status', 'published')
            ->orderBy('title')
            ->get();

        return view('admin.pages.create', compact('parentPages'));
    }

    /**
     * Store a newly created page.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'nullable|string|max:255|unique:pages,slug',
            'content' => 'nullable|string',
            'excerpt' => 'nullable|string|max:500',
            'featured_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:5120',
            'hero_heading' => 'nullable|string|max:255',
            'hero_subheading' => 'nullable|string|max:500',
            'hero_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:5120',
            'sections' => 'nullable',
            'meta_title' => 'nullable|string|max:70',
            'meta_description' => 'nullable|string|max:160',
            'meta_keywords' => 'nullable|string|max:255',
            'status' => 'required|in:draft,published,archived',
            'template' => 'nullable|string|max:50',
            'parent_id' => 'nullable|exists:pages,id',
            'order' => 'nullable|integer|min:0',
        ]);

        // Auto-generate slug if not provided
        if (empty($validated['slug'])) {
            $validated['slug'] = Str::slug($validated['title']);
        }

        // Handle file uploads
        foreach (['hero_image', 'featured_image'] as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs('public/pages', $filename);
                $validated[$field] = 'pages/' . $filename;
            }
        }

        // Handle sections: array from form fields or string JSON (backward compat)
        if (isset($validated['sections'])) {
            if (is_array($validated['sections'])) {
                $validated['sections'] = $this->cleanSections($validated['sections']);
            } elseif (is_string($validated['sections'])) {
                $decoded = json_decode($validated['sections'], true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $validated['sections'] = $decoded;
                }
            }
        }

        $validated['created_by'] = $this->user()->id;
        $validated['updated_by'] = $this->user()->id;

        $page = Page::create($validated);

        ActivityLog::log(
            'create',
            "Created page: {$page->title}",
            Page::class,
            $page->id
        );

        return redirect()->route('admin.pages.index')
            ->with('success', 'Page created successfully.');
    }

    /**
     * Display the specified page.
     */
    public function show(Page $page)
    {
        return view('admin.pages.show', compact('page'));
    }

    /**
     * Show the form for editing the page.
     */
    public function edit(Page $page)
    {
        $parentPages = Page::where('status', 'published')
            ->where('id', '!=', $page->id)
            ->orderBy('title')
            ->get();

        return view('admin.pages.edit', compact('page', 'parentPages'));
    }

    /**
     * Update the specified page.
     */
    public function update(Request $request, Page $page)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'slug' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('pages', 'slug')->ignore($page->id),
            ],
            'content' => 'nullable|string',
            'excerpt' => 'nullable|string|max:500',
            'featured_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:5120',
            'hero_heading' => 'nullable|string|max:255',
            'hero_subheading' => 'nullable|string|max:500',
            'hero_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:5120',
            'sections' => 'nullable',
            'meta_title' => 'nullable|string|max:70',
            'meta_description' => 'nullable|string|max:160',
            'meta_keywords' => 'nullable|string|max:255',
            'status' => 'required|in:draft,published,archived',
            'template' => 'nullable|string|max:50',
            'parent_id' => 'nullable|exists:pages,id',
            'order' => 'nullable|integer|min:0',
        ]);

        $oldValues = $page->toArray();

        if (empty($validated['slug'])) {
            $validated['slug'] = Str::slug($validated['title']);
        }

        // Handle file uploads
        foreach (['hero_image', 'featured_image'] as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs('public/pages', $filename);
                $validated[$field] = 'pages/' . $filename;
            }
            // Handle remove checkbox
            if ($request->has('remove_' . $field)) {
                $validated[$field] = null;
            }
        }

        // Handle sections: array from form fields or string JSON (backward compat)
        if (isset($validated['sections'])) {
            if (is_array($validated['sections'])) {
                $validated['sections'] = $this->cleanSections($validated['sections']);
            } elseif (is_string($validated['sections'])) {
                $decoded = json_decode($validated['sections'], true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $validated['sections'] = $decoded;
                }
            }
        }

        $validated['updated_by'] = $this->user()->id;

        $page->update($validated);

        ActivityLog::log(
            'update',
            "Updated page: {$page->title}",
            Page::class,
            $page->id,
            $oldValues,
            $page->fresh()->toArray()
        );

        return redirect()->route('admin.pages.index')
            ->with('success', 'Page updated successfully.');
    }

    /**
     * Remove the specified page.
     */
    public function destroy(Page $page)
    {
        $pageTitle = $page->title;
        
        $page->delete();

        ActivityLog::log(
            'delete',
            "Deleted page: {$pageTitle}",
            Page::class,
            $page->id
        );

        return redirect()->route('admin.pages.index')
            ->with('success', 'Page deleted successfully.');
    }

    /**
     * Bulk delete pages.
     */
    public function bulkDelete(Request $request)
    {
        $validated = $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:pages,id',
        ]);

        $pages = Page::whereIn('id', $validated['ids'])->get();

        foreach ($pages as $page) {
            ActivityLog::log(
                'delete',
                "Deleted page: {$page->title}",
                Page::class,
                $page->id
            );
            $page->delete();
        }

        return redirect()->route('admin.pages.index')
            ->with('success', count($pages) . ' pages deleted successfully.');
    }

    /**
     * Remove empty rows and clean section arrays.
     */
    protected function cleanSections(array $sections): array
    {
        foreach ($sections as $key => &$value) {
            if (is_array($value)) {
                // Check if it's a numeric array (repeatable items)
                if (array_keys($value) === range(0, count($value) - 1)) {
                    $value = array_values(array_filter($value, function ($item) {
                        return is_array($item) && !empty(trim(implode('', $item)));
                    }));
                    // Clean nested values
                    foreach ($value as &$item) {
                        if (is_array($item)) {
                            $item = array_map('trim', $item);
                        }
                    }
                }
            }
        }
        return $sections;
    }
}
