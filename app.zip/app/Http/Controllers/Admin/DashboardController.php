<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Models\Page;
use App\Models\Contact;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Carbon\Carbon;

class DashboardController extends AdminController
{
    /**
     * Display the admin dashboard.
     */
    public function index()
    {
        $stats = $this->getStats();
        $recentContacts = Contact::orderBy('created_at', 'desc')->take(5)->get();
        $recentActivity = ActivityLog::with('user')->orderBy('created_at', 'desc')->take(10)->get();
        $contactsChart = $this->getContactsChartData();
        $usersChart = $this->getUsersChartData();

        return view('admin.dashboard', compact(
            'stats',
            'recentContacts',
            'recentActivity',
            'contactsChart',
            'usersChart'
        ));
    }

    /**
     * Get dashboard statistics.
     */
    protected function getStats(): array
    {
        return [
            'total_users' => User::count(),
            'total_pages' => Page::count(),
            'total_contacts' => Contact::count(),
            'new_contacts' => Contact::where('status', 'new')->count(),
            'published_pages' => Page::where('status', 'published')->count(),
            'draft_pages' => Page::where('status', 'draft')->count(),
        ];
    }

    /**
     * Get contacts chart data.
     */
    protected function getContactsChartData(): array
    {
        $months = [];
        $counts = [];

        for ($i = 5; $i >= 0; $i--) {
            $month = Carbon::now()->subMonths($i);
            $months[] = $month->format('M Y');
            
            $counts[] = Contact::whereYear('created_at', $month->year)
                ->whereMonth('created_at', $month->month)
                ->count();
        }

        return [
            'labels' => $months,
            'data' => $counts,
        ];
    }

    /**
     * Get users chart data.
     */
    protected function getUsersChartData(): array
    {
        $months = [];
        $counts = [];

        for ($i = 5; $i >= 0; $i--) {
            $month = Carbon::now()->subMonths($i);
            $months[] = $month->format('M Y');
            
            $counts[] = User::whereYear('created_at', $month->year)
                ->whereMonth('created_at', $month->month)
                ->count();
        }

        return [
            'labels' => $months,
            'data' => $counts,
        ];
    }
}
