<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class SystemController extends Controller
{
    /**
     * Display system information.
     */
    public function info()
    {
        $info = [
            'php_version' => PHP_VERSION,
            'laravel_version' => app()->version(),
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'database_driver' => config('database.default'),
            'cache_driver' => config('cache.default'),
            'session_driver' => config('session.driver'),
            'mail_driver' => config('mail.default'),
        ];
        
        return view('admin.system.info', compact('info'));
    }

    /**
     * Display activity logs.
     */
    public function logs()
    {
        $logs = ActivityLog::latest()->paginate(50);
        return view('admin.system.logs', compact('logs'));
    }

    /**
     * Clear application cache.
     */
    public function clearCache()
    {
        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('view:clear');
        
        ActivityLog::log('cache_clear', 'Application cache cleared');
        
        return redirect()->back()->with('success', 'Application cache cleared successfully.');
    }

    /**
     * Clear application logs.
     */
    public function clearLogs()
    {
        $logFile = storage_path('logs/laravel.log');
        
        if (file_exists($logFile)) {
            file_put_contents($logFile, '');
            ActivityLog::log('logs_clear', 'Application logs cleared');
            return redirect()->back()->with('success', 'Logs cleared successfully.');
        }
        
        return redirect()->back()->with('error', 'No logs found to clear.');
    }

    /**
     * Optimize application.
     */
    public function optimize()
    {
        Artisan::call('config:cache');
        Artisan::call('route:cache');
        Artisan::call('view:cache');
        
        ActivityLog::log('optimize', 'Application optimized');
        
        return redirect()->back()->with('success', 'Application optimized successfully.');
    }

    /**
     * Run database migrations.
     */
    public function migrate()
    {
        Artisan::call('migrate', ['--force' => true]);
        
        ActivityLog::log('migrate', 'Database migrations executed');
        
        return redirect()->back()->with('success', 'Migrations executed successfully.');
    }

    /**
     * Seed database.
     */
    public function seed()
    {
        Artisan::call('db:seed', ['--force' => true]);
        
        ActivityLog::log('seed', 'Database seeded');
        
        return redirect()->back()->with('success', 'Database seeded successfully.');
    }

    /**
     * Generate application key.
     */
    public function keyGenerate()
    {
        Artisan::call('key:generate', ['--force' => true]);
        
        ActivityLog::log('key_generate', 'Application key regenerated');
        
        return redirect()->back()->with('success', 'Application key generated successfully.');
    }
}
