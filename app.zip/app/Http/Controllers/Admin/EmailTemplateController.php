<?php

namespace App\Http\Controllers\Admin;

use App\Models\EmailTemplate;
use App\Models\ActivityLog;
use Illuminate\Http\Request;

class EmailTemplateController extends AdminController
{
    /**
     * Display a listing of email templates.
     */
    public function index(Request $request)
    {
        $query = EmailTemplate::query();

        if ($request->has('type') && $request->type !== 'all') {
            $query->where('type', $request->type);
        }

        if ($request->has('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('subject', 'like', '%' . $request->search . '%');
            });
        }

        $templates = $query->orderBy('name')->paginate(15);

        $types = EmailTemplate::select('type')->distinct()->whereNotNull('type')->pluck('type');

        return view('admin.email-templates.index', compact('templates', 'types'));
    }

    /**
     * Show the form for creating a new template.
     */
    public function create()
    {
        return view('admin.email-templates.create');
    }

    /**
     * Store a newly created template.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'body' => 'required|string',
            'type' => 'nullable|string|max:50',
            'status' => 'required|in:active,inactive',
        ]);

        // Extract variables from template
        preg_match_all('/\{\{(\w+)\}\}/', $validated['subject'] . ' ' . $validated['body'], $matches);
        $variables = array_unique($matches[1]);

        $validated['variables'] = json_encode($variables);
        $validated['created_by'] = $this->user()->id;
        $validated['updated_by'] = $this->user()->id;

        $template = EmailTemplate::create($validated);

        ActivityLog::log(
            'create',
            "Created email template: {$template->name}",
            EmailTemplate::class,
            $template->id
        );

        return redirect()->route('admin.email-templates.index')
            ->with('success', 'Email template created successfully.');
    }

    /**
     * Display the specified template.
     */
    public function show(EmailTemplate $emailTemplate)
    {
        return view('admin.email-templates.show', compact('emailTemplate'));
    }

    /**
     * Show the form for editing the template.
     */
    public function edit(EmailTemplate $emailTemplate)
    {
        return view('admin.email-templates.edit', compact('emailTemplate'));
    }

    /**
     * Update the specified template.
     */
    public function update(Request $request, EmailTemplate $emailTemplate)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'subject' => 'required|string|max:255',
            'body' => 'required|string',
            'type' => 'nullable|string|max:50',
            'status' => 'required|in:active,inactive',
        ]);

        $oldValues = $emailTemplate->toArray();

        // Extract variables from template
        preg_match_all('/\{\{(\w+)\}\}/', $validated['subject'] . ' ' . $validated['body'], $matches);
        $variables = array_unique($matches[1]);

        $validated['variables'] = json_encode($variables);
        $validated['updated_by'] = $this->user()->id;

        $emailTemplate->update($validated);

        ActivityLog::log(
            'update',
            "Updated email template: {$emailTemplate->name}",
            EmailTemplate::class,
            $emailTemplate->id,
            $oldValues,
            $emailTemplate->fresh()->toArray()
        );

        return redirect()->route('admin.email-templates.index')
            ->with('success', 'Email template updated successfully.');
    }

    /**
     * Remove the specified template.
     */
    public function destroy(EmailTemplate $emailTemplate)
    {
        $templateName = $emailTemplate->name;
        
        $emailTemplate->delete();

        ActivityLog::log(
            'delete',
            "Deleted email template: {$templateName}",
            EmailTemplate::class,
            $emailTemplate->id
        );

        return redirect()->route('admin.email-templates.index')
            ->with('success', 'Email template deleted successfully.');
    }

    /**
     * Duplicate a template.
     */
    public function duplicate(EmailTemplate $emailTemplate)
    {
        $newTemplate = $emailTemplate->replicate();
        $newTemplate->name = $emailTemplate->name . ' (Copy)';
        $newTemplate->created_by = $this->user()->id;
        $newTemplate->updated_by = $this->user()->id;
        $newTemplate->save();

        ActivityLog::log(
            'create',
            "Duplicated email template: {$newTemplate->name}",
            EmailTemplate::class,
            $newTemplate->id
        );

        return redirect()->route('admin.email-templates.edit', $newTemplate->id)
            ->with('success', 'Template duplicated. You can now edit it.');
    }

    /**
     * Preview template with sample data.
     */
    public function preview(Request $request, EmailTemplate $emailTemplate)
    {
        $sampleData = [
            'name' => 'John Doe',
            'email' => 'john@example.com',
            'phone' => '+1234567890',
            'subject' => 'Sample Subject',
            'message' => 'This is a sample message for preview purposes.',
            'site_name' => 'WP Marine Limited',
            'site_url' => url('/'),
            'date' => now()->format('Y-m-d H:i:s'),
        ];

        $emailData = $emailTemplate->replaceVariables($sampleData);

        return view('admin.email-templates.preview', [
            'template' => $emailTemplate,
            'preview' => $emailData,
        ]);
    }

    /**
     * Send test email.
     */
    public function sendTest(Request $request, EmailTemplate $emailTemplate)
    {
        $validated = $request->validate([
            'test_email' => 'required|email',
        ]);

        $sampleData = [
            'name' => 'Test User',
            'email' => $validated['test_email'],
            'phone' => '+1234567890',
            'subject' => 'Test Subject',
            'message' => 'This is a test message.',
            'site_name' => 'WP Marine Limited',
            'site_url' => url('/'),
            'date' => now()->format('Y-m-d H:i:s'),
        ];

        $emailData = $emailTemplate->replaceVariables($sampleData);

        try {
            \Illuminate\Support\Facades\Mail::html($emailData['body'], function ($message) use ($emailData, $validated) {
                $message->to($validated['test_email'])
                    ->subject($emailData['subject']);
            });

            return redirect()->back()->with('success', 'Test email sent successfully.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to send test email: ' . $e->getMessage());
        }
    }

    /**
     * Create default templates.
     */
    public function createDefaults()
    {
        $defaults = EmailTemplate::defaults();

        foreach ($defaults as $default) {
            EmailTemplate::firstOrCreate(
                ['type' => $default['type']],
                $default
            );
        }

        return redirect()->route('admin.email-templates.index')
            ->with('success', 'Default templates created.');
    }
}
