<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    use AuthorizesRequests, ValidatesRequests;

    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin');
    }

    /**
     * Get the authenticated user.
     */
    protected function user()
    {
        return Auth::user();
    }

    /**
     * Redirect to dashboard.
     */
    protected function redirectToDashboard()
    {
        return redirect()->route('admin.dashboard');
    }
}
