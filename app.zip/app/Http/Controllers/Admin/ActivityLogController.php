<?php

namespace App\Http\Controllers\Admin;

use App\Models\ActivityLog;
use Illuminate\Http\Request;

class ActivityLogController extends AdminController
{
    /**
     * Display a listing of activity logs.
     */
    public function index(Request $request)
    {
        $query = ActivityLog::with('user');

        if ($request->has('action') && $request->action !== 'all') {
            $query->where('action', $request->action);
        }

        if ($request->has('user') && $request->user !== 'all') {
            $query->where('user_id', $request->user);
        }

        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $logs = $query->orderBy('created_at', 'desc')->paginate(30);

        $users = ActivityLog::select('user_id')->distinct()
            ->with('user')
            ->get()
            ->pluck('user.name', 'user_id')
            ->filter();

        $actions = ActivityLog::select('action')->distinct()->pluck('action');

        return view('admin.activity-logs.index', compact('logs', 'users', 'actions'));
    }

    /**
     * Display the specified activity log.
     */
    public function show(ActivityLog $activityLog)
    {
        $activityLog->load('user');
        
        return view('admin.activity-logs.show', compact('activityLog'));
    }

    /**
     * Export activity logs.
     */
    public function export(Request $request)
    {
        $query = ActivityLog::with('user');

        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $logs = $query->orderBy('created_at', 'desc')->get();

        $csvContent = "ID,User,Action,Description,IP Address,Date\n";
        
        foreach ($logs as $log) {
            $csvContent .= sprintf(
                "%d,%s,%s,%s,%s,%s\n",
                $log->id,
                $log->user->name ?? 'System',
                $log->action,
                str_replace(',', ';', $log->description),
                $log->ip_address ?? '',
                $log->created_at->format('Y-m-d H:i:s')
            );
        }

        return response($csvContent)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', 'attachment; filename="activity_logs_' . date('Y-m-d') . '.csv"');
    }

    /**
     * Clear old logs.
     */
    public function clearOld(Request $request)
    {
        $validated = $request->validate([
            'days' => 'required|integer|min:1|max:365',
        ]);

        $date = now()->subDays($validated['days']);
        
        $deleted = ActivityLog::where('created_at', '<', $date)->delete();

        return redirect()->route('admin.activity-logs.index')
            ->with('success', $deleted . ' old activity logs cleared.');
    }
}
