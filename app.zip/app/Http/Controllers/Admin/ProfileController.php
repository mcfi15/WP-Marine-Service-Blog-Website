<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;

class ProfileController extends AdminController
{
    /**
     * Show the edit profile form.
     */
    public function edit()
    {
        $user = $this->user();
        return view('admin.profile.edit', compact('user'));
    }

    /**
     * Update the authenticated user's profile.
     */
    public function update(Request $request)
    {
        $user = $this->user();

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'email',
                Rule::unique('users', 'email')->ignore($user->id),
            ],
            'avatar' => 'nullable|string|max:255',
        ]);

        $oldValues = $user->toArray();
        $user->update($validated);

        ActivityLog::log(
            'update',
            'Updated own profile',
            User::class,
            $user->id,
            $oldValues,
            $user->fresh()->toArray()
        );

        return redirect()->route('admin.profile.edit')
            ->with('success', 'Profile updated successfully.');
    }

    /**
     * Update the authenticated user's password.
     */
    public function updatePassword(Request $request)
    {
        $user = $this->user();

        $validated = $request->validate([
            'current_password' => ['required', function ($attribute, $value, $fail) use ($user) {
                if (!Hash::check($value, $user->password)) {
                    $fail('The current password is incorrect.');
                }
            }],
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        $user->update(['password' => Hash::make($validated['password'])]);

        ActivityLog::log(
            'update',
            'Changed own password',
            User::class,
            $user->id
        );

        return redirect()->route('admin.profile.edit')
            ->with('success', 'Password changed successfully.');
    }
}
