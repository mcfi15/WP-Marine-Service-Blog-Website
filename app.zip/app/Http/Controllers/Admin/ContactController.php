<?php

namespace App\Http\Controllers\Admin;

use App\Models\Contact;
use App\Models\ActivityLog;
use Illuminate\Http\Request;

class ContactController extends AdminController
{
    /**
     * Display a listing of contacts.
     */
    public function index(Request $request)
    {
        $query = Contact::query();

        if ($request->has('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('email', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $contacts = $query->orderBy('created_at', 'desc')->paginate(15);

        $statusCounts = [
            'all' => Contact::count(),
            'new' => Contact::where('status', 'new')->count(),
            'read' => Contact::where('status', 'read')->count(),
            'replied' => Contact::where('status', 'replied')->count(),
            'archived' => Contact::where('status', 'archived')->count(),
        ];

        return view('admin.contacts.index', compact('contacts', 'statusCounts'));
    }

    /**
     * Display the specified contact.
     */
    public function show(Contact $contact)
    {
        // Mark as read when viewed
        if ($contact->status === 'new') {
            $contact->markAsRead();
        }

        return view('admin.contacts.show', compact('contact'));
    }

    /**
     * Mark contact as read.
     */
    public function markAsRead(Contact $contact)
    {
        $contact->markAsRead();

        ActivityLog::log(
            'update',
            "Marked contact as read: {$contact->name}",
            Contact::class,
            $contact->id
        );

        return redirect()->back()->with('success', 'Contact marked as read.');
    }

    /**
     * Mark contact as replied.
     */
    public function markAsReplied(Contact $contact)
    {
        $contact->markAsReplied();

        ActivityLog::log(
            'update',
            "Marked contact as replied: {$contact->name}",
            Contact::class,
            $contact->id
        );

        return redirect()->back()->with('success', 'Contact marked as replied.');
    }

    /**
     * Archive contact.
     */
    public function archive(Contact $contact)
    {
        $contact->update(['status' => 'archived']);

        ActivityLog::log(
            'update',
            "Archived contact: {$contact->name}",
            Contact::class,
            $contact->id
        );

        return redirect()->route('admin.contacts.index')
            ->with('success', 'Contact archived successfully.');
    }

    /**
     * Remove the specified contact.
     */
    public function destroy(Contact $contact)
    {
        $contactName = $contact->name;
        
        $contact->delete();

        ActivityLog::log(
            'delete',
            "Deleted contact: {$contactName}",
            Contact::class,
            $contact->id
        );

        return redirect()->route('admin.contacts.index')
            ->with('success', 'Contact deleted successfully.');
    }

    /**
     * Bulk update contacts.
     */
    public function bulkUpdate(Request $request)
    {
        $validated = $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:contacts,id',
            'action' => 'required|in:mark_read,mark_replied,archive,delete',
        ]);

        $contacts = Contact::whereIn('id', $validated['ids']);

        switch ($validated['action']) {
            case 'mark_read':
                $contacts->update(['status' => 'read']);
                $message = 'Contacts marked as read.';
                break;
            case 'mark_replied':
                $contacts->update(['status' => 'replied']);
                $message = 'Contacts marked as replied.';
                break;
            case 'archive':
                $contacts->update(['status' => 'archived']);
                $message = 'Contacts archived.';
                break;
            case 'delete':
                $contacts->delete();
                $message = 'Contacts deleted.';
                break;
        }

        return redirect()->route('admin.contacts.index')
            ->with('success', $message);
    }

    /**
     * Export contacts.
     */
    public function export(Request $request)
    {
        $query = Contact::query();

        if ($request->has('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $contacts = $query->orderBy('created_at', 'desc')->get();

        $csvContent = $this->generateCsv($contacts);

        return response($csvContent)
            ->header('Content-Type', 'text/csv')
            ->header('Content-Disposition', 'attachment; filename="contacts_' . date('Y-m-d') . '.csv"');
    }

    /**
     * Generate CSV content.
     */
    protected function generateCsv($contacts)
    {
        ob_start();
        $output = fopen('php://output', 'w');
        
        fputcsv($output, ['ID', 'Name', 'Email', 'Phone', 'Subject', 'Message', 'Status', 'Date']);
        
        foreach ($contacts as $contact) {
            fputcsv($output, [
                $contact->id,
                $contact->name,
                $contact->email,
                $contact->phone,
                $contact->subject,
                $contact->message,
                $contact->status,
                $contact->created_at->format('Y-m-d H:i:s'),
            ]);
        }
        
        fclose($output);
        return ob_get_clean();
    }
}
