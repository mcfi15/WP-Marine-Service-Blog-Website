<?php

namespace App\Http\Controllers\Admin;

use App\Models\Setting;
use App\Models\ActivityLog;
use Illuminate\Http\Request;

class SettingController extends AdminController
{
    /**
     * Display settings page.
     */
    public function index()
    {
        $settings = Setting::getGroupedSettings();
        $groups = Setting::select('group')->distinct()->pluck('group');

        return view('admin.settings.index', compact('settings', 'groups'));
    }

    /**
     * Display general settings.
     */
    public function general()
    {
        $settings = Setting::byGroup('general')->get();
        
        return view('admin.settings.general', compact('settings'));
    }

    /**
     * Display email settings.
     */
    public function email()
    {
        $settings = Setting::byGroup('email')->get();
        
        return view('admin.settings.email', compact('settings'));
    }

    /**
     * Display SEO settings.
     */
    public function seo()
    {
        $settings = Setting::byGroup('seo')->get();
        
        return view('admin.settings.seo', compact('settings'));
    }

    /**
     * Display integration settings.
     */
    public function integrations()
    {
        $settings = Setting::byGroup('integrations')->get();
        
        return view('admin.settings.integrations', compact('settings'));
    }

    /**
     * Update settings.
     */
    public function update(Request $request)
    {
        $validated = $request->except(['_token', '_method']);

        // Handle file uploads
        $fileFields = ['site_dark_logo', 'site_light_logo', 'site_favicon'];
        foreach ($fileFields as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs('public/settings', $filename);
                $validated[$field] = 'settings/' . $filename;
            }
            if ($request->has('remove_' . $field)) {
                $validated[$field] = null;
            }
        }

        // Handle unchecked checkboxes: set to 0 if field name contains 'enabled'
        $booleanFields = ['analytics_enabled', 'recaptcha_enabled', 'live_chat_enabled', 'gdpr_enabled', 'gdpr_cookie_banner'];
        foreach ($booleanFields as $field) {
            if (!isset($validated[$field])) {
                $validated[$field] = 0;
            }
        }

        foreach ($validated as $key => $value) {
            $setting = Setting::where('key', $key)->first();

            if ($setting) {
                $oldValue = $setting->value;
                $setting->update(['value' => $value]);
                if ($oldValue !== $value) {
                    ActivityLog::log(
                        'update',
                        "Updated setting: {$key}",
                        Setting::class,
                        $setting->id,
                        ['old' => $oldValue],
                        ['new' => $value]
                    );
                }
            } else {
                Setting::create([
                    'key' => $key,
                    'value' => $value,
                    'type' => in_array($key, ['site_dark_logo', 'site_light_logo', 'site_favicon']) ? 'image' : 'text',
                    'group' => 'general',
                ]);
            }
        }

        return redirect()->back()->with('success', 'Settings updated successfully.');
    }

    /**
     * Update site identity settings.
     */
    public function updateSiteIdentity(Request $request)
    {
        $validated = $request->validate([
            'site_name' => 'required|string|max:255',
            'site_tagline' => 'nullable|string|max:255',
            'site_description' => 'nullable|string|max:500',
            'site_dark_logo' => 'nullable|string|max:255',
            'site_light_logo' => 'nullable|string|max:255',
            'site_favicon' => 'nullable|string|max:255',
        ]);

        foreach ($validated as $key => $value) {
            Setting::setValue($key, $value, 'text', 'general');
        }

        ActivityLog::log('update', 'Updated site identity settings');

        return redirect()->back()->with('success', 'Site identity updated successfully.');
    }

    /**
     * Update contact settings.
     */
    public function updateContactSettings(Request $request)
    {
        $validated = $request->validate([
            'contact_email' => 'required|email|max:255',
            'contact_phone' => 'nullable|string|max:50',
            'contact_address' => 'nullable|string|max:500',
            'contact_map_embed' => 'nullable|string',
        ]);

        foreach ($validated as $key => $value) {
            Setting::setValue($key, $value, 'text', 'contact');
        }

        ActivityLog::log('update', 'Updated contact settings');

        return redirect()->back()->with('success', 'Contact settings updated successfully.');
    }

    /**
     * Update social media settings.
     */
    public function updateSocialSettings(Request $request)
    {
        $validated = $request->validate([
            'social_facebook' => 'nullable|url|max:255',
            'social_twitter' => 'nullable|url|max:255',
            'social_linkedin' => 'nullable|url|max:255',
            'social_instagram' => 'nullable|url|max:255',
        ]);

        foreach ($validated as $key => $value) {
            Setting::setValue($key, $value, 'text', 'social');
        }

        ActivityLog::log('update', 'Updated social media settings');

        return redirect()->back()->with('success', 'Social media settings updated successfully.');
    }

    /**
     * Update Google Analytics settings.
     */
    public function updateAnalyticsSettings(Request $request)
    {
        $validated = $request->validate([
            'google_analytics_id' => 'nullable|string|max:50',
            'google_tag_manager_id' => 'nullable|string|max:50',
            'analytics_enabled' => 'nullable|boolean',
        ]);

        foreach ($validated as $key => $value) {
            $type = $key === 'analytics_enabled' ? 'boolean' : 'text';
            Setting::setValue($key, $value, $type, 'integrations');
        }

        ActivityLog::log('update', 'Updated Google Analytics settings');

        return redirect()->back()->with('success', 'Analytics settings updated successfully.');
    }

    /**
     * Update reCAPTCHA settings.
     */
    public function updateRecaptchaSettings(Request $request)
    {
        $validated = $request->validate([
            'recaptcha_site_key' => 'nullable|string|max:255',
            'recaptcha_secret_key' => 'nullable|string|max:255',
            'recaptcha_enabled' => 'nullable|boolean',
        ]);

        foreach ($validated as $key => $value) {
            $type = $key === 'recaptcha_enabled' ? 'boolean' : 'text';
            Setting::setValue($key, $value, $type, 'integrations');
        }

        ActivityLog::log('update', 'Updated reCAPTCHA settings');

        return redirect()->back()->with('success', 'reCAPTCHA settings updated successfully.');
    }

    /**
     * Update mail settings.
     */
    public function updateMailSettings(Request $request)
    {
        $validated = $request->validate([
            'mail_mailer' => 'required|string|max:50',
            'mail_host' => 'required|string|max:255',
            'mail_port' => 'required|numeric',
            'mail_username' => 'nullable|string|max:255',
            'mail_password' => 'nullable|string|max:255',
            'mail_encryption' => 'nullable|string|max:10',
            'mail_from_address' => 'required|email|max:255',
            'mail_from_name' => 'required|string|max:255',
        ]);

        foreach ($validated as $key => $value) {
            Setting::setValue($key, $value, 'text', 'email');
        }

        ActivityLog::log('update', 'Updated mail settings');

        return redirect()->back()->with('success', 'Mail settings updated successfully.');
    }

    /**
     * Update settings for a specific group.
     */
    public function updateGroup(Request $request)
    {
        $validated = $request->except(['_token', '_method', '_group']);
        $group = $request->input('_group', 'general');

        foreach ($validated as $key => $value) {
            Setting::setValue($key, $value, 'text', $group);
        }

        ActivityLog::log('update', 'Updated ' . $group . ' settings');

        return redirect()->back()->with('success', ucfirst($group) . ' settings updated successfully.');
    }

    /**
     * Reset settings to default.
     */
    public function resetToDefault()
    {
        Setting::truncate();
        
        ActivityLog::log('reset', 'Reset all settings to default');

        return redirect()->route('admin.settings.index')
            ->with('success', 'Settings reset to default.');
    }
}
