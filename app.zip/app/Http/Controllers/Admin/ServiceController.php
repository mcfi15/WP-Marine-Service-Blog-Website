<?php

namespace App\Http\Controllers\Admin;

use App\Models\Service;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ServiceController extends AdminController
{
    public function index(Request $request)
    {
        $query = Service::with('creator');

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('short_description', 'like', '%' . $request->search . '%');
            });
        }

        $services = $query->orderBy('sort_order')->orderBy('title')->paginate(15);

        return view('admin.services.index', compact('services'));
    }

    public function create()
    {
        return view('admin.services.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'slug' => 'nullable|string|max:255|unique:services,slug',
            'short_description' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:5120',
            'icon' => 'nullable|string|max:100',
            'sort_order' => 'nullable|integer|min:0',
            'status' => 'required|in:published,draft',
        ]);

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = 'service_' . time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/services', $filename);
            $validated['image'] = 'services/' . $filename;
        }

        $validated['created_by'] = $this->user()->id;

        $service = Service::create($validated);

        ActivityLog::log('create', "Created service: {$service->title}", Service::class, $service->id);

        return redirect()->route('admin.services.index')
            ->with('success', 'Service created successfully.');
    }

    public function edit(Service $service)
    {
        return view('admin.services.edit', compact('service'));
    }

    public function update(Request $request, Service $service)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'slug' => [
                'nullable', 'string', 'max:255',
                Rule::unique('services', 'slug')->ignore($service->id),
            ],
            'short_description' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp,svg|max:5120',
            'icon' => 'nullable|string|max:100',
            'sort_order' => 'nullable|integer|min:0',
            'status' => 'required|in:published,draft',
        ]);

        $oldValues = $service->toArray();

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = 'service_' . time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('public/services', $filename);
            $validated['image'] = 'services/' . $filename;
        }

        if ($request->has('remove_image')) {
            $validated['image'] = null;
        }

        $service->update($validated);

        ActivityLog::log(
            'update',
            "Updated service: {$service->title}",
            Service::class,
            $service->id,
            $oldValues,
            $service->fresh()->toArray()
        );

        return redirect()->route('admin.services.index')
            ->with('success', 'Service updated successfully.');
    }

    public function destroy(Service $service)
    {
        $title = $service->title;
        $service->delete();

        ActivityLog::log('delete', "Deleted service: {$title}", Service::class, $service->id);

        return redirect()->route('admin.services.index')
            ->with('success', 'Service deleted successfully.');
    }
}
