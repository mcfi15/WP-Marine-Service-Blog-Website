<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\Models\Service;
use App\Models\Contact;
use App\Models\Setting;
use App\Services\SeoService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class HomeController extends Controller
{
    protected $seoService;

    public function __construct(SeoService $seoService)
    {
        $this->seoService = $seoService;
    }

    public function index()
    {
        $page = Page::where('slug', 'home')->published()->first();
        $services = Service::published()->ordered()->limit(3)->get();
        $seoData = $this->seoService->getSeoData('home');

        return view('frontend.home', compact('page', 'services', 'seoData'));
    }

    public function about()
    {
        $page = Page::where('slug', 'about-us')->published()->first();
        $seoData = $this->seoService->getSeoData('about-us');

        return view('frontend.about', compact('page', 'seoData'));
    }

    public function offer()
    {
        $page = Page::where('slug', 'our-range')->published()->first();
        $services = Service::published()->ordered()->get();
        $seoData = $this->seoService->getSeoData('our-range');

        return view('frontend.offer', compact('page', 'services', 'seoData'));
    }

    public function serviceDetail($serviceSlug)
    {
        $service = Service::where('slug', $serviceSlug)->published()->firstOrFail();
        $seoData = $this->seoService->getSeoData('our-range');

        return view('frontend.service-detail', compact('service', 'seoData'));
    }

    public function clients()
    {
        $page = Page::where('slug', 'our-customers')->published()->first();
        $seoData = $this->seoService->getSeoData('our-customers');

        return view('frontend.clients', compact('page', 'seoData'));
    }

    public function contact()
    {
        $page = Page::where('slug', 'contact')->published()->first();
        $seoData = $this->seoService->getSeoData('contact');

        return view('frontend.contact', compact('page', 'seoData'));
    }

    public function submitContact(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:50',
            'subject' => 'nullable|string|max:255',
            'message' => 'required|string|max:5000',
        ]);

        $validated['ip_address'] = $request->ip();
        $validated['user_agent'] = $request->userAgent();

        $contact = Contact::create($validated);

        $this->sendContactNotification($contact);

        return redirect()->back()->with('success', 'Thank you for your message. We will get back to you soon.');
    }

    protected function sendContactNotification(Contact $contact)
    {
        $settings = Setting::getGroupedSettings();
        $siteName = $settings['general']['site_name'] ?? 'WP Marine Limited';

        $emailTemplate = \App\Models\EmailTemplate::where('type', 'contact')
            ->where('status', 'active')
            ->first();

        if ($emailTemplate) {
            $variables = [
                'name' => $contact->name,
                'email' => $contact->email,
                'phone' => $contact->phone,
                'subject' => $contact->subject,
                'message' => $contact->message,
                'site_name' => $siteName,
                'date' => now()->format('Y-m-d H:i:s'),
            ];

            $emailData = $emailTemplate->replaceVariables($variables);

            Mail::send([], [], function ($message) use ($contact, $emailData, $settings) {
                $message->to($settings['email']['contact_email'] ?? 'info@wpmarinelimited.com')
                    ->subject($emailData['subject'])
                    ->html($emailData['body']);
            });
        }
    }

    public function page($slug)
    {
        $page = Page::where('slug', $slug)->published()->firstOrFail();
        $seoData = $this->seoService->getSeoData($slug);

        return view('frontend.page', compact('page', 'seoData'));
    }
}
