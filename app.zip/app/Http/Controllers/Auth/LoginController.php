<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\ActivityLog;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('admin.auth.login');
    }

    public function login(Request $request)
    {
        logger('LOGIN_DEBUG', ['step' => 'entered', 'email' => $request->email]);

        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        logger('LOGIN_DEBUG', ['step' => 'validation_passed']);

        $credentials = $request->only('email', 'password');
        $attempted = Auth::attempt($credentials);

        logger('LOGIN_DEBUG', ['step' => 'attempted', 'result' => $attempted]);

        if ($attempted) {
            $request->session()->regenerate();
            logger('LOGIN_DEBUG', ['step' => 'session_regenerated', 'user_id' => Auth::id()]);
            ActivityLog::log('login', 'User logged in', User::class, Auth::id());
            return redirect()->intended(route('admin.dashboard'))
                ->with('success', 'Welcome back!');
        }

        logger('LOGIN_DEBUG', ['step' => 'failed']);
        return back()->withInput()->withErrors([
            'email' => 'These credentials do not match our records.',
        ]);
    }

    public function logout(Request $request)
    {
        if (Auth::check()) {
            ActivityLog::log('logout', 'User logged out', User::class, Auth::id());
        }
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/')->with('success', 'Logged out successfully.');
    }
}
