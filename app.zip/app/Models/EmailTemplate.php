<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EmailTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'subject',
        'body',
        'variables',
        'type',
        'status',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'variables' => 'array',
        'status' => 'string',
        'created_by' => 'integer',
        'updated_by' => 'integer',
    ];

    /**
     * Default email templates.
     */
    public static function defaults(): array
    {
        return [
            [
                'name' => 'Contact Form',
                'subject' => 'New Contact Form Submission - {{site_name}}',
                'body' => 'You have received a new contact form submission:<br><br>
Name: {{name}}<br>
Email: {{email}}<br>
Phone: {{phone}}<br>
Subject: {{subject}}<br>
Message: {{message}}<br><br>
Sent: {{date}}',
                'variables' => json_encode(['name', 'email', 'phone', 'subject', 'message', 'site_name', 'date']),
                'type' => 'contact',
                'status' => 'active',
            ],
            [
                'name' => 'Welcome Email',
                'subject' => 'Welcome to {{site_name}}',
                'body' => 'Dear {{name}},<br><br>
Welcome to {{site_name}}!<br><br>
Thank you for your interest in our marine services. We look forward to serving you.<br><br>
Best regards,<br>
{{site_name}} Team',
                'variables' => json_encode(['name', 'site_name', 'site_url']),
                'type' => 'welcome',
                'status' => 'active',
            ],
        ];
    }

    /**
     * Get the user who created the template.
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /**
     * Replace variables in template.
     */
    public function replaceVariables(array $data): array
    {
        $subject = $this->subject;
        $body = $this->body;

        foreach ($this->variables as $variable) {
            $placeholder = '{{' . $variable . '}}';
            $value = $data[$variable] ?? '';
            
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }

        return [
            'subject' => $subject,
            'body' => $body,
        ];
    }
}
